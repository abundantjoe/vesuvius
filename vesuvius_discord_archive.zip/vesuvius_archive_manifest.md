# Vesuvius Challenge Discord Archive Manifest

- JSON export files: **731**
- Valid JSON files: **731**
- Message records across files: **41734**
- Earliest exported timestamp: **2023-02-27T23:36:13.823+00:00**
- Latest exported timestamp: **2026-10-20T23:47:23.562+00:00**
- Excluded by request: `#intros`, `#find-a-team`

## Newly completed requested channels

`#unrolling-vc3d`, `#papyrology`, and `#speculation` were exported successfully with all discovered threads.

## Remaining access limitations

The following channels were not available to the exporter account: `#github`, `#private-research`, `#private-team`, `#segmenters`, `#aws-monitoring-alerts`, and `#firstletters`. Three general-channel threads remained unavailable after retry due transport failures. These are not silently represented as empty channels.
