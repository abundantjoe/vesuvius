"""
Tests for nml_toolkit. Run with:  python -m pytest tests/ -v
(or: python -m unittest discover tests)

Two kinds of tests:
  - Synthetic tests: build a tiny in-memory NML XML string covering edge
    cases (branch point, single node, empty thing) so behaviour is checked
    against a known-correct hand-computed answer, independent of any
    particular dataset.
  - Dataset tests: if the real fiber-skeletons NML files are present on
    disk (set NML_TEST_DIR env var or rely on the default path below),
    run consistency checks against them too. These are skipped gracefully
    if the data isn't available, so the suite still runs in any environment.
"""

from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path

from nml_toolkit.parser import parse_nml, parse_cube_id_from_filename
from nml_toolkit.convert import to_csv, to_json, to_swc
from nml_toolkit.stats import annotation_summary, orientation_vector


SYNTHETIC_NML = """<?xml version="1.0" encoding="UTF-8"?>
<things>
  <meta name="username" content="Test User"/>
  <parameters>
    <experiment name="synthetic" organization="test" description=""/>
    <scale x="7.91" y="7.91" z="7.91" unit="micrometer"/>
    <offset x="0" y="0" z="0"/>
    <userBoundingBox id="1" name="Full Cube" isVisible="true"
        color.r="1.0" color.g="0.0" color.b="0.0" color.a="1.0"
        topLeftX="100" topLeftY="200" topLeftZ="300" width="256" height="256" depth="256"/>
  </parameters>
  <thing id="1" color.r="1.0" color.g="0.0" color.b="0.0" color.a="1.0" name="straight_fiber" type="DEFAULT">
    <nodes>
      <node id="10" radius="1.0" x="0" y="0" z="0"/>
      <node id="11" radius="1.0" x="3" y="4" z="0"/>
      <node id="12" radius="1.0" x="6" y="8" z="0"/>
    </nodes>
    <edges>
      <edge source="10" target="11"/>
      <edge source="11" target="12"/>
    </edges>
  </thing>
  <thing id="2" color.r="0.0" color.g="1.0" color.b="0.0" color.a="1.0" name="branching_fiber" type="DEFAULT">
    <nodes>
      <node id="20" radius="1.0" x="0" y="0" z="0"/>
      <node id="21" radius="1.0" x="1" y="0" z="0"/>
      <node id="22" radius="1.0" x="2" y="0" z="0"/>
      <node id="23" radius="1.0" x="2" y="1" z="0"/>
      <node id="24" radius="1.0" x="2" y="-1" z="0"/>
    </nodes>
    <edges>
      <edge source="20" target="21"/>
      <edge source="21" target="22"/>
      <edge source="22" target="23"/>
      <edge source="22" target="24"/>
    </edges>
  </thing>
  <thing id="3" color.r="0.0" color.g="0.0" color.b="1.0" color.a="1.0" name="single_node_fiber" type="DEFAULT">
    <nodes>
      <node id="30" radius="2.5" x="5" y="5" z="5"/>
    </nodes>
    <edges/>
  </thing>
  <thing id="4" color.r="0.0" color.g="0.0" color.b="0.0" color.a="1.0" name="empty_fiber" type="DEFAULT">
    <nodes/>
    <edges/>
  </thing>
  <branchpoints/>
  <comments/>
  <groups/>
</things>
"""


class TestParser(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.nml_path = Path(self.tmpdir.name) / "fibers_s1a_00300z_00200y_00100x_256_v00.nml"
        self.nml_path.write_text(SYNTHETIC_NML)
        self.ann = parse_nml(self.nml_path)

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_counts(self):
        self.assertEqual(self.ann.num_fibers(), 4)
        self.assertEqual(self.ann.total_nodes(), 3 + 5 + 1 + 0)

    def test_scale_and_offset(self):
        self.assertEqual(self.ann.scale, (7.91, 7.91, 7.91))
        self.assertEqual(self.ann.scale_unit, "micrometer")
        self.assertEqual(self.ann.offset, (0.0, 0.0, 0.0))

    def test_full_cube_bbox(self):
        bbox = self.ann.full_cube_bbox
        self.assertIsNotNone(bbox)
        self.assertEqual(bbox.top_left, (100, 200, 300))
        self.assertEqual(bbox.size, (256, 256, 256))

    def test_straight_fiber_is_simple_path_and_ordered(self):
        t = next(t for t in self.ann.things if t.id == 1)
        self.assertTrue(t.is_simple_path())
        ordered = t.ordered_path()
        self.assertEqual([n.id for n in ordered], [10, 11, 12])

    def test_straight_fiber_length(self):
        # (0,0,0) -> (3,4,0) is length 5 ; (3,4,0)->(6,8,0) is length 5 -> total 10
        t = next(t for t in self.ann.things if t.id == 1)
        self.assertAlmostEqual(t.length_voxels(), 10.0, places=6)

    def test_branching_fiber_detected(self):
        t = next(t for t in self.ann.things if t.id == 2)
        self.assertFalse(t.is_simple_path())
        deg = t.degree()
        self.assertEqual(deg[22], 3)  # the branch point
        self.assertEqual(deg[20], 1)  # an endpoint
        self.assertEqual(deg[23], 1)
        self.assertEqual(deg[24], 1)

    def test_single_node_fiber(self):
        t = next(t for t in self.ann.things if t.id == 3)
        self.assertEqual(len(t.nodes), 1)
        ordered = t.ordered_path()
        self.assertEqual(len(ordered), 1)
        self.assertEqual(t.length_voxels(), 0.0)

    def test_empty_fiber(self):
        t = next(t for t in self.ann.things if t.id == 4)
        self.assertEqual(len(t.nodes), 0)
        self.assertEqual(t.ordered_path(), [])
        self.assertEqual(t.length_voxels(), 0.0)
        self.assertIsNone(t.bounding_box())

    def test_cube_id_from_filename(self):
        cid = parse_cube_id_from_filename(self.nml_path)
        self.assertIsNotNone(cid)
        self.assertEqual(cid.scroll, "s1a")
        self.assertEqual((cid.z, cid.y, cid.x), (300, 200, 100))
        self.assertEqual(cid.size, 256)
        self.assertEqual(cid.version, 0)
        self.assertEqual(cid.matching_image_stem, "s1_00300_00200_00100_256")

    def test_bad_root_tag_raises(self):
        bad_path = Path(self.tmpdir.name) / "not_nml.nml"
        bad_path.write_text("<notathing></notathing>")
        with self.assertRaises(ValueError):
            parse_nml(bad_path)


class TestConverters(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        nml_path = Path(self.tmpdir.name) / "fibers_s1a_00300z_00200y_00100x_256_v00.nml"
        nml_path.write_text(SYNTHETIC_NML)
        self.ann = parse_nml(nml_path)
        self.out_dir = Path(self.tmpdir.name) / "out"
        self.out_dir.mkdir()

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_csv_row_count(self):
        path = to_csv(self.ann, self.out_dir / "out.csv")
        with path.open() as f:
            lines = f.readlines()
        # header + nodes from fibers 1,2,3 (fiber 4 has none) = 1 + (3+5+1)
        self.assertEqual(len(lines), 1 + 9)

    def test_csv_branch_flags(self):
        path = to_csv(self.ann, self.out_dir / "out.csv")
        import csv as csv_mod

        with path.open() as f:
            rows = list(csv_mod.DictReader(f))
        branch_rows = [r for r in rows if r["fiber_id"] == "2" and r["node_id"] == "22"]
        self.assertEqual(len(branch_rows), 1)
        self.assertEqual(branch_rows[0]["is_branch_point"], "True")

    def test_json_roundtrip_node_count(self):
        import json

        path = to_json(self.ann, self.out_dir / "out.json")
        data = json.loads(path.read_text())
        self.assertEqual(data["num_fibers"], 4)
        total_nodes_in_json = sum(len(f["nodes"]) for f in data["fibers"])
        self.assertEqual(total_nodes_in_json, 9)
        self.assertEqual(data["cube"]["matching_nnunet_stem"], "s1_00300_00200_00100_256")

    def test_json_preserves_branch_topology(self):
        import json

        path = to_json(self.ann, self.out_dir / "out.json")
        data = json.loads(path.read_text())
        fiber2 = next(f for f in data["fibers"] if f["fiber_id"] == 2)
        self.assertFalse(fiber2["is_simple_path"])
        self.assertEqual(len(fiber2["edges"]), 4)

    def test_swc_one_file_per_nonempty_fiber(self):
        paths = to_swc(self.ann, self.out_dir / "swc")
        # 4 things total, 1 empty -> 3 files
        self.assertEqual(len(paths), 3)

    def test_swc_root_has_parent_minus_one(self):
        paths = to_swc(self.ann, self.out_dir / "swc")
        straight = next(p for p in paths if "fiber0001" in p.name)
        lines = [l for l in straight.read_text().splitlines() if not l.startswith("#")]
        self.assertEqual(len(lines), 3)
        cols = lines[0].split()
        self.assertEqual(int(cols[-1]), -1)  # first emitted node is the root

    def test_swc_branch_point_has_two_children(self):
        paths = to_swc(self.ann, self.out_dir / "swc")
        branch = next(p for p in paths if "fiber0002" in p.name)
        lines = [l for l in branch.read_text().splitlines() if not l.startswith("#")]
        self.assertEqual(len(lines), 5)
        parents = [int(l.split()[-1]) for l in lines]
        ids = [int(l.split()[0]) for l in lines]
        # exactly one root
        self.assertEqual(parents.count(-1), 1)
        # the branch node (originally degree 3) should appear as parent twice
        from collections import Counter

        parent_counts = Counter(p for p in parents if p != -1)
        self.assertIn(2, parent_counts.values())

    def test_swc_combined_single_file(self):
        paths = to_swc(self.ann, self.out_dir / "swc_combined", combine=True)
        self.assertEqual(len(paths), 1)
        lines = [l for l in paths[0].read_text().splitlines() if not l.startswith("#")]
        self.assertEqual(len(lines), 9)  # 3 + 5 + 1 nodes across non-empty fibers


class TestStats(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        nml_path = Path(self.tmpdir.name) / "fibers_s1a_00300z_00200y_00100x_256_v00.nml"
        nml_path.write_text(SYNTHETIC_NML)
        self.ann = parse_nml(nml_path)

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_summary_counts(self):
        s = annotation_summary(self.ann)
        self.assertEqual(s.num_fibers, 4)
        self.assertEqual(s.num_fibers_with_nodes, 3)
        self.assertEqual(s.num_branching_fibers, 1)
        self.assertEqual(s.scroll, "s1a")
        self.assertEqual(s.cube_size, 256)

    def test_orientation_vectors_are_unit_length(self):
        vectors = orientation_vector(self.ann)
        self.assertEqual(len(vectors), 2)  # fiber 3 (single node) excluded
        for _, (x, y, z) in vectors:
            norm = (x * x + y * y + z * z) ** 0.5
            self.assertAlmostEqual(norm, 1.0, places=6)


@unittest.skipUnless(
    os.path.isdir(
        os.environ.get(
            "NML_TEST_DIR",
            "/home/claude/work/fiber-skeletons/Dataset001_sk-fibers-20250124/nml",
        )
    ),
    "Real dataset not available in this environment; skipping dataset-backed tests.",
)
class TestAgainstRealDataset(unittest.TestCase):
    """
    Sanity checks against the actual Vesuvius Challenge fiber-skeletons
    dataset, when present. These confirm the parser handles every real file
    without error and that filenames map correctly onto the accompanying
    nnU-Net imagesTr stems.
    """

    NML_DIR = os.environ.get(
        "NML_TEST_DIR",
        "/home/claude/work/fiber-skeletons/Dataset001_sk-fibers-20250124/nml",
    )

    def test_all_files_parse_without_error(self):
        nml_files = sorted(Path(self.NML_DIR).glob("*.nml"))
        self.assertGreater(len(nml_files), 0)
        for f in nml_files:
            with self.subTest(file=f.name):
                ann = parse_nml(f)
                self.assertGreater(ann.num_fibers(), 0)

    def test_cube_ids_decode_for_every_file(self):
        nml_files = sorted(Path(self.NML_DIR).glob("*.nml"))
        for f in nml_files:
            with self.subTest(file=f.name):
                cid = parse_cube_id_from_filename(f)
                self.assertIsNotNone(cid)
                self.assertIn(cid.size, (256, 512))

    def test_total_fiber_count_matches_expected(self):
        # Cross-check against the totals this toolkit reported during
        # development (see README); guards against silent regressions.
        nml_files = sorted(Path(self.NML_DIR).glob("*.nml"))
        total_fibers = sum(parse_nml(f).num_fibers() for f in nml_files)
        total_nodes = sum(parse_nml(f).total_nodes() for f in nml_files)
        self.assertEqual(total_fibers, 2489)
        self.assertEqual(total_nodes, 92641)


if __name__ == "__main__":
    unittest.main()
