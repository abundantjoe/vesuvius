"""
nml_toolkit.convert
====================

Converts parsed WEBKNOSSOS NML fiber annotations into formats that don't
require WEBKNOSSOS (or any specific viewer) to consume:

  - CSV       : one row per node, with fiber id and edge-derived ordering.
                Opens in any spreadsheet tool, pandas, R, etc.
  - JSON      : the full node/edge graph per fiber, preserving exact topology
                (including branch points), nested under metadata about the
                source cube. Best choice if you need the graph structure,
                not just an ordered point list.
  - SWC       : the standard neuron/tree morphology format used throughout
                connectomics and neuroscience tooling (Vaa3D, neuTube, navis,
                etc). Each fiber becomes one SWC tree. Useful because it's a
                well-supported, simple text format with existing viewers and
                analysis libraries, and fibers and traced axons/dendrites are
                structurally the same object (a tree of connected 3D points
                with radius).

All exports preserve absolute voxel coordinates in the scroll's own coordinate
frame (matching the nnU-Net imagesTr/labelsTr volumes), not cube-relative
coordinates, so a fiber traced in one cube can still be related to neighboring
or overlapping cubes.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Optional

from .parser import NmlAnnotation, Thing, parse_cube_id_from_filename


def _fiber_records(ann: NmlAnnotation) -> list[dict]:
    """Build one row per node, in fiber-then-path order, with metadata columns."""
    rows = []
    for t in ann.things:
        ordered = t.ordered_path() if t.is_simple_path() else t.nodes
        deg = t.degree()
        for i, n in enumerate(ordered):
            rows.append(
                {
                    "fiber_id": t.id,
                    "fiber_name": t.name,
                    "node_id": n.id,
                    "order_in_fiber": i,
                    "x": n.x,
                    "y": n.y,
                    "z": n.z,
                    "radius": n.radius,
                    "degree": deg.get(n.id, 0),
                    "is_branch_point": deg.get(n.id, 0) >= 3,
                    "is_endpoint": deg.get(n.id, 0) <= 1,
                }
            )
    return rows


def to_csv(ann: NmlAnnotation, out_path: str | Path) -> Path:
    """
    Write one row per traced node to CSV.

    Columns: fiber_id, fiber_name, node_id, order_in_fiber, x, y, z, radius,
    degree, is_branch_point, is_endpoint.

    `order_in_fiber` walks the fiber from one endpoint to the other for
    simple (unbranched) fibers. For the small number of fibers that contain
    a branch point, nodes are instead emitted in raw NML order and
    `order_in_fiber` should not be treated as a walk order — use the JSON
    export's edge list to reconstruct topology for those fibers.
    """
    out_path = Path(out_path)
    rows = _fiber_records(ann)
    fieldnames = [
        "fiber_id",
        "fiber_name",
        "node_id",
        "order_in_fiber",
        "x",
        "y",
        "z",
        "radius",
        "degree",
        "is_branch_point",
        "is_endpoint",
    ]
    with out_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return out_path


def to_json(ann: NmlAnnotation, out_path: str | Path) -> Path:
    """
    Write the full graph (nodes + edges, per fiber) to JSON, alongside cube
    metadata (scale, absolute origin, source file). This is the most
    information-preserving export: it keeps exact topology, including
    branch points, which the CSV path-order does not.
    """
    out_path = Path(out_path)
    cube_id = parse_cube_id_from_filename(ann.source_path)
    full_bbox = ann.full_cube_bbox

    data = {
        "source_file": ann.source_path.name,
        "scale": {"x": ann.scale[0], "y": ann.scale[1], "z": ann.scale[2], "unit": ann.scale_unit},
        "offset": {"x": ann.offset[0], "y": ann.offset[1], "z": ann.offset[2]},
        "cube": (
            {
                "scroll": cube_id.scroll,
                "origin_zyx": [cube_id.z, cube_id.y, cube_id.x],
                "size": cube_id.size,
                "annotation_version": cube_id.version,
                "matching_nnunet_stem": cube_id.matching_image_stem,
            }
            if cube_id
            else None
        ),
        "full_cube_bounding_box": (
            {
                "top_left_xyz": list(full_bbox.top_left),
                "size_xyz": list(full_bbox.size),
            }
            if full_bbox
            else None
        ),
        "annotator": ann.meta.get("username"),
        "num_fibers": ann.num_fibers(),
        "num_nodes": ann.total_nodes(),
        "fibers": [
            {
                "fiber_id": t.id,
                "name": t.name,
                "is_simple_path": t.is_simple_path(),
                "length_voxels": round(t.length_voxels(), 3),
                "nodes": [
                    {"id": n.id, "x": n.x, "y": n.y, "z": n.z, "radius": n.radius}
                    for n in t.nodes
                ],
                "edges": [{"source": e.source, "target": e.target} for e in t.edges],
            }
            for t in ann.things
        ],
    }
    out_path.write_text(json.dumps(data, indent=2))
    return out_path


def to_swc(ann: NmlAnnotation, out_dir: str | Path, *, combine: bool = False) -> list[Path]:
    """
    Write SWC files (one per fiber, by default) using the standard 7-column
    SWC morphology format:

        n  type  x  y  z  radius  parent

    `type` is set to 2 ("axon") for all nodes as a neutral default — SWC
    type codes are neuron-specific and don't map cleanly onto fiber strands,
    but most SWC-reading tools require a valid integer here.

    For fibers with a branch point, the parent pointer correctly encodes the
    tree structure (each node's parent is the previous node visited in a
    depth-first walk from the root), so no topology is lost, unlike the CSV
    path export.

    If combine=True, writes a single SWC file containing all fibers in the
    cube, with node ids offset to stay globally unique (most SWC viewers
    treat disconnected components fine, since each fiber's root has parent
    -1).

    Returns the list of file paths written.
    """
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []

    def thing_to_swc_lines(t: Thing, id_offset: int = 0) -> list[str]:
        if not t.nodes:
            return []
        adj: dict[int, list[int]] = {n.id: [] for n in t.nodes}
        for e in t.edges:
            adj[e.source].append(e.target)
            adj[e.target].append(e.source)

        deg = {nid: len(neighbors) for nid, neighbors in adj.items()}
        endpoints = [nid for nid, d in deg.items() if d <= 1]
        root = endpoints[0] if endpoints else t.nodes[0].id

        by_id = t.node_by_id
        # remap NML node ids -> dense 1..N SWC ids, offset for global uniqueness
        swc_id: dict[int, int] = {}
        lines: list[str] = []
        parent_of: dict[int, int] = {root: -1}

        visited = {root}
        stack = [root]
        order = []
        while stack:
            cur = stack.pop()
            order.append(cur)
            for nb in adj[cur]:
                if nb not in visited:
                    visited.add(nb)
                    parent_of[nb] = cur
                    stack.append(nb)

        for nid in order:
            swc_id[nid] = len(swc_id) + 1 + id_offset

        for nid in order:
            n = by_id[nid]
            parent_nml = parent_of.get(nid, -1)
            parent_swc = swc_id[parent_nml] if parent_nml != -1 else -1
            lines.append(
                f"{swc_id[nid]} 2 {n.x:.3f} {n.y:.3f} {n.z:.3f} {n.radius:.3f} {parent_swc}"
            )
        return lines

    if combine:
        out_path = out_dir / f"{ann.source_path.stem}.swc"
        all_lines = [
            "# SWC export of all fibers in one cube",
            f"# source: {ann.source_path.name}",
            "# n type x y z radius parent",
        ]
        offset = 0
        for t in ann.things:
            lines = thing_to_swc_lines(t, id_offset=offset)
            if lines:
                all_lines.append(f"# fiber_id={t.id} name={t.name}")
                all_lines.extend(lines)
                offset += len(t.nodes)
        out_path.write_text("\n".join(all_lines) + "\n")
        written.append(out_path)
    else:
        for t in ann.things:
            if not t.nodes:
                continue
            lines = thing_to_swc_lines(t)
            if not lines:
                continue
            out_path = out_dir / f"{ann.source_path.stem}_fiber{t.id:04d}.swc"
            header = [
                f"# SWC export of fiber {t.id} ({t.name})",
                f"# source: {ann.source_path.name}",
                "# n type x y z radius parent",
            ]
            out_path.write_text("\n".join(header + lines) + "\n")
            written.append(out_path)

    return written
