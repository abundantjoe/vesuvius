"""
examples/analyze_fiber_orientation.py
======================================

Demonstrates a concrete use of the converted data: checking whether fibers
within each cube are predominantly aligned along one direction, which is the
expected behaviour within a single papyrus sheet layer (per the Vesuvius
Challenge FAQ: the outer/back layer of a sheet carries vertical fibers, the
inner/front layer with writing carries horizontal fibers -- see
https://scrollprize.org/faq).

Produces:
  - fiber_length_histogram.png   : distribution of fiber lengths (in microns)
                                    across all cubes, grouped by scroll
  - fiber_orientation_summary.csv : per-cube dominant orientation axis and
                                     how strongly fibers agree with it
                                     ("alignment score": mean |cos angle|
                                     between each fiber and the cube's
                                     dominant axis; 1.0 = perfectly aligned,
                                     ~0.5-0.6 = isotropic/random in 3D)

Run from the repository root:
    python examples/analyze_fiber_orientation.py /path/to/nml_dir /path/to/output_dir
"""

from __future__ import annotations

import csv
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from nml_toolkit.parser import parse_nml, parse_cube_id_from_filename
from nml_toolkit.stats import orientation_vector


def dominant_axis_and_alignment(vectors: list[tuple[int, tuple[float, float, float]]]):
    """
    Given per-fiber unit direction vectors, find the dominant axis via the
    leading eigenvector of the (sign-insensitive) orientation tensor
    sum(v v^T), then report the mean |cos(angle)| of each fiber to that axis
    as an alignment score.
    """
    if not vectors:
        return None, 0.0

    V = np.array([v for _, v in vectors])
    # Orientation tensor: sign-insensitive (a fiber pointing "up" or "down"
    # along its own length is the same physical orientation)
    T = V.T @ V
    eigvals, eigvecs = np.linalg.eigh(T)
    dominant = eigvecs[:, np.argmax(eigvals)]
    dominant = dominant / np.linalg.norm(dominant)

    cos_angles = np.abs(V @ dominant)
    return dominant, float(np.mean(cos_angles))


def main(nml_dir: str, out_dir: str):
    nml_dir_p = Path(nml_dir)
    out_dir_p = Path(out_dir)
    out_dir_p.mkdir(parents=True, exist_ok=True)

    nml_files = sorted(nml_dir_p.glob("*.nml"))
    if not nml_files:
        print(f"No .nml files found in {nml_dir}", file=sys.stderr)
        return 1

    summary_rows = []
    all_lengths = {}  # scroll -> list of lengths in microns

    for f in nml_files:
        ann = parse_nml(f)
        cube_id = parse_cube_id_from_filename(f)
        scale_um = ann.scale[0]  # isotropic in this dataset

        vectors = orientation_vector(ann)
        dominant, alignment = dominant_axis_and_alignment(vectors)

        lengths_um = [t.length_voxels() * scale_um for t in ann.things if t.nodes]
        scroll = cube_id.scroll if cube_id else "unknown"
        all_lengths.setdefault(scroll, []).extend(lengths_um)

        summary_rows.append(
            {
                "file": f.name,
                "scroll": scroll,
                "num_fibers": ann.num_fibers(),
                "dominant_axis_x": round(float(dominant[0]), 3) if dominant is not None else "",
                "dominant_axis_y": round(float(dominant[1]), 3) if dominant is not None else "",
                "dominant_axis_z": round(float(dominant[2]), 3) if dominant is not None else "",
                "alignment_score": round(alignment, 3),
                "mean_length_um": round(float(np.mean(lengths_um)), 1) if lengths_um else 0.0,
            }
        )
        print(
            f"{f.name}: {ann.num_fibers()} fibers, alignment={alignment:.3f}, "
            f"dominant_axis=({dominant[0]:.2f}, {dominant[1]:.2f}, {dominant[2]:.2f})"
            if dominant is not None
            else f"{f.name}: no fibers with >=2 nodes"
        )

    csv_path = out_dir_p / "fiber_orientation_summary.csv"
    with csv_path.open("w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=list(summary_rows[0].keys()))
        writer.writeheader()
        writer.writerows(summary_rows)
    print(f"\nWrote {csv_path}")

    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(8, 5))
        for scroll, lengths in all_lengths.items():
            ax.hist(lengths, bins=40, alpha=0.6, label=f"{scroll} (n={len(lengths)})")
        ax.set_xlabel("Fiber length (micrometers)")
        ax.set_ylabel("Count")
        ax.set_title("Traced papyrus fiber length distribution")
        ax.legend()
        fig.tight_layout()
        png_path = out_dir_p / "fiber_length_histogram.png"
        fig.savefig(png_path, dpi=150)
        print(f"Wrote {png_path}")
    except ImportError:
        print("matplotlib not installed; skipping histogram plot (CSV summary still written).")

    return 0


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print(f"Usage: python {sys.argv[0]} NML_DIR OUTPUT_DIR", file=sys.stderr)
        raise SystemExit(1)
    raise SystemExit(main(sys.argv[1], sys.argv[2]))
